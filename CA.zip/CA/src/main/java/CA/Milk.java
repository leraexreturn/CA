package CA;

public interface Milk
{





}
